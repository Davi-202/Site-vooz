let synth = window.speechSynthesis;
let utterance;

function playAudio() {
  const text = document.getElementById("prompt").value;
  if (!text.trim()) {
    alert("Please write a prompt first.");
    return;
  }

  utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "en-US";
  synth.cancel(); // stop any current speech
  synth.speak(utterance);
}

function pauseAudio() {
  if (synth.speaking && !synth.paused) {
    synth.pause();
  }
}

function resumeAudio() {
  if (synth.paused) {
    synth.resume();
  }
}

function downloadAudio() {
  alert("Baixar o áudio só é possível com servidor backend. No GitHub Pages, não dá para baixar diretamente o áudio gerado pela Web Speech API.");
}
